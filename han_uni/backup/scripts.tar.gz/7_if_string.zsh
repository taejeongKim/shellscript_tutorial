#!/bin/zsh

var=$1

if [[ -z $var ]]; then
	echo "null string"
else
	echo "String : $1"

fi
