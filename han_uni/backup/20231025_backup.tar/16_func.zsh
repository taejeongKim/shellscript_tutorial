#!/bin/zsh

test_func(){
	echo "Hello World"
}

test_func
