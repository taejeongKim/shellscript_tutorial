#!/bin/zsh

if [[ $1 -lt 10 ]]; then
	echo "This is one digit number"
else
	echo "This is double digit number"

fi
