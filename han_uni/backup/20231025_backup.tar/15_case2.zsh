#!/bin/zsh

case $1 in
	start) 
			echo "starting ... "
			;;
	stop)
			echo "stopping ... "
			;;
	*)
			echo "I don't know ... "
			;;
esac
