#!/bin/zsh

if [[ -z $1 ]];then
	echo "null string"
else
	echo "string : $1"
fi

