#!/bin/zsh

for i in $(ls);
do echo "item: $i"
done


