#!/bin/zsh

echo "args Count : $#"
echo "script name : $0"
echo "first arg : $1"
echo "second arg : $2"
echo "how many args : $#"
echo "all args : $@"
