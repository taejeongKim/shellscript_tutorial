#!/bin/zsh

echo "Enter String"
read var1
echo "Input is $var1"

echo "Enter String"
read var2
echo "Input is $var2"


echo "Enter String"
read var3
echo "Input is $var3"

